[vc_row container_type="content-fixed" padding="padding-medium" padding_top="40" padding_bottom="40" fixed_height="0" bgtype="bg-custom-color" bgcolor="#f4f4f4" bgparallax="bg-parallax" map_type="ROADMAP" map_zoom="12" map_scroll="false" map_drag="false" map_zoom_control="false" map_disable_doubleclick="true" map_streetview="false" bgmask_color="#000000" bgmask_color_opacity="0.9" bgimage_position="top left" bgimage_repeat="no-repeat" bgimage_attach="scroll" css_animation_delay="0" section_arrow="arrow-down"][vc_column width="1/1"][vc_row_inner][vc_column_inner width="2/3"][md_slider size="md-two-thirds" effect="fade" images="3874,3878" css_animation_delay="0" navigation="true" pagination="true"][/vc_column_inner][vc_column_inner width="1/3"][md_text css_animation_delay="0"]
<h5>DATE</h5>
29 December 2014

&nbsp;
<h5>CATEGORY</h5>
Develop, Interactive

&nbsp;
<h5>ABOUT THE PROJECT</h5>
Aliquam cursus velit velit, ut facilisis magna varius sit amet. Nullam ac feugiat magna. Aliquam lobortis dolor eget massa dictum auctor. Duis hendrerit pulvinar libero eu aliquam. Praesent sagittis risus eu arcu lobortis rhoncus. In hac habitasse platea dictumst. Suspendisse hendrerit risus at justo sagittis adipiscing. Aenean sed felis eget mi dignissim tincidunt. Vivamus congue rhoncus ultricies.[/md_text][md_blank_space height="40"][md_button href="#" size="small" style="style-1" color="#ffffff" colorhover="#ffffff" bgcolor="#16a085" icon_family="typicons" icon_fontawesome="icon-glass" icon_typicons="typcn-adjust-brightness" icon_entypo="entypo-note" icon_lineicons="lineicon-banknote" css_animation_delay="0"]VIEW ONLINE[/md_button][md_blank_space height="40"][md_social_share_classic facebook="yes" twitter="yes" googleplus="yes" pinterest="yes" css_animation_delay="0"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]