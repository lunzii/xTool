<?php


$output = '<div class="clearfix"></div>';

echo $output;