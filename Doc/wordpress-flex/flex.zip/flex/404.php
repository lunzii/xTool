<?php get_header(); ?>

	<div class="page-content" id="404-container">
		<div class="container">
			<?php get_template_part('/templates/page/content-404');?>
		</div>
	</div>
	
<?php get_footer(); ?>